#pragma once

#include "quantum.h"



extern	const uint8_t mix_data_tab[][3];
extern const uint8_t colour_library_tab[][3];
extern  const uint8_t breathe_mode_tab[];