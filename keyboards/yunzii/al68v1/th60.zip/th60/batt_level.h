#pragma once

#include "quantum.h"
#include "analog.h"


// #define BATT_0  3200
// #define BATT_5  3300
// #define BATT_10 3330
// #define BATT_15 3360
// #define BATT_20 3420
// #define BATT_25 3440
// #define BATT_30 3490
// #define BATT_35 3520
// #define BATT_40 3540
// #define BATT_45 3580
// #define BATT_50 3630
// #define BATT_55 3650
// #define BATT_60 3700
// #define BATT_65 3750
// #define BATT_70 3790
// #define BATT_75 3820
// #define BATT_80 3910
// #define BATT_85 3950
// #define BATT_90 3980
// #define BATT_95 4030
// #define BATT_100 4150



// uint16_t get_adc_value(uint8_t chaanel);
// uint16_t get_adc(void);
// uint8_t batt_level(void);






