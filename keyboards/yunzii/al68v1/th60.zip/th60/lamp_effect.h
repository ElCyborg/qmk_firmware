#pragma once

#include "quantum.h"




void rgblight_off(uint8_t min,uint8_t max);                         //灭灯
void indicator_argblight_mode(uint8_t min,uint8_t max,uint8_t mode,uint8_t single);     //指示灯模式设置